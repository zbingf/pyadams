
# TCP CMD

## ADAMS连接方式
+ 通过TCP控制adams

## 后处理方案
+ win32com 操作 word

## 程序结构
Code.xlsx



# 版本
version 1.12
    + 修改 get_aggregate_mass 函数

version 2.05
	+ 改成独立程序, 不再调用pyadams
	+ 修改日志设置形式

version 2.12
	+ 变量存储切换成mat格式
	+ 基于appJar创建后处理UI

