
"""
	后处理数据对比模块
"""

"""
数据格式要求

	data_a = {
		'reqs': [], # request
		'comps': [], # component
		'comments':[], # 注释横坐标
		'list2d':[[], [],...], # 与reqs有序对应
	}

	data_b = ...

"""






