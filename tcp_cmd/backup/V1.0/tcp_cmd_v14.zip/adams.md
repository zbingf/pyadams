



# 启动command_server 
```
command_server start

```

# 调用外部程序

```
var set var=.mdi.command_server.pydummy real = (eval(run_python_code('import os')))
var set var=.mdi.command_server.py_dummy_cl real=(eval(run_python_code('os.popen("temp.txt")')))
```


# 终止command_server
```
command_Server stop
```

