
# ADAMS cmd命令


## command_server 


command_server show
    | var set var=.mdi.command_server.pydummy real = (eval(run_python_code('import mdi.command_server as command_server')))
    | var set var=.mdi.command_server.py_dummy_cl real=(eval(run_python_code('command_server.listener_dialog.show()')))



command_server start
    | var set var=.mdi.command_server.pydummy real = (eval(run_python_code('import mdi.command_server as command_server')))
    | var set var=.mdi.command_server.py_dummy_cl real=(eval(run_python_code('command_server.listener_dialog.start_clicked()')))


command_server stop
    | var set var=.mdi.command_server.pydummy real = (eval(run_python_code('import mdi.command_server as command_server')))
    | var set var=.mdi.command_server.py_dummy_cl real=(eval(run_python_code('command_server.listener_dialog.stop_clicked()')))


