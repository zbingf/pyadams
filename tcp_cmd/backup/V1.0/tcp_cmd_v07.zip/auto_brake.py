from pyadams.tcp_cmd import tcp_car, post_brake, post_static_only
from pyadams.file import office_docx
WordEdit = office_docx.WordEdit

import os

def remove_figs(figs):
    for fig_path in figs:
        os.remove(fig_path)



class AutoCurBrake:

    def __init__(self, params):

        self.params = params
        self.word_path = params['word_path']
        self.new_word_path = params['new_word_path']

    # static仿真
    def sim_static(self):
        # 静态计算
        self.result_static = tcp_car.main_cur_static_only()

    # brake仿真
    def sim_brake(self):

        self.result_brake = tcp_car.sim_cur_brake()

    # static数据编辑目标
    def word_static_list(self):

        self.statics = post_static_only.post_static_only(self.result_static)    

    # brake数据编辑目标
    def word_brake_list(self):

        self.r_figs, self.r_strs = post_brake.post_brake(self.result_brake)

    # 文档编辑
    def word_brake_edit(self):
        
        word_obj = WordEdit(self.word_path)
        word_obj.replace_edit(*self.statics)
        word_obj.replace_edit(*self.r_figs)
        word_obj.replace_edit(*self.r_strs)
        word_obj.save(self.new_word_path)
        word_obj.close()

    # 删除图片
    def remove_figs(self):
        
        remove_figs(self.r_figs[1])

    # csv数据记录
    def record_static(self):
        post_static_only.csv_post_static_only_print(self.result_static)




# word文档编辑 测试
params = {
    'word_path': r'post_brake.docx',
    'new_word_path': r'new_post_brake.docx',

}

obj = AutoCurBrake(params)
obj.sim_static()
obj.sim_brake()
obj.word_static_list()
obj.word_brake_list()
obj.record_static()