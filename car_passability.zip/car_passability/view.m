
load('state.mat')


scatter(loc_edge(:,1), loc_edge(:,2), 'r')
